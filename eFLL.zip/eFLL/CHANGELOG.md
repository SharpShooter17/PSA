# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.10] - 2017-08-21
### Added
- CHARGELOG.md file to document this project.

### Changed
- The way that FuzzyOutput truncate trapezoidals funcctions, improve the acurace.
- File headers with author references.

### Removed
- None.